package app;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;

import controller.AdminController;
import controller.ShopController;
import dao.AdminDao;
import dao.OrderDao;
import dao.ProductDao;
import dao.impl.AdminDaoJdbc;
import dao.impl.OrderDaoJdbc;
import dao.impl.ProductDaoJdbc;
import service.AdminService;
import service.ShopService;
import view.ShopFrame;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); }
            catch (Exception ignored) {}

            // DAO
            ProductDao productDao = new ProductDaoJdbc();
            OrderDao orderDao = new OrderDaoJdbc();
            AdminDao adminDao = new AdminDaoJdbc();

            // Service
            ShopService shopService = new ShopService(productDao, orderDao);
            AdminService adminService = new AdminService(adminDao, productDao, orderDao);

            // Controller
            ShopController shopController = new ShopController(shopService);
            AdminController adminController = new AdminController(adminService);

            // UI
            ShopFrame frame = new ShopFrame(shopController, adminController);
            frame.setVisible(true);
        });
    }
}
