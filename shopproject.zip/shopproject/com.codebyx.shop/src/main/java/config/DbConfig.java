package config;


public class DbConfig {
    public static final String URL =
        "jdbc:mysql://localhost:3306/shopdb?useSSL=false&serverTimezone=Asia/Taipei&characterEncoding=utf8";
    public static final String USER = "root";
    public static final String PASS = "1234";
}
