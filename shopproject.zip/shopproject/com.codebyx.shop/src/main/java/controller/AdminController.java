package controller;

import java.util.List;

import model.Order;
import model.OrderItem;
import model.Product;
import service.AdminService;

public class AdminController {
    private final AdminService adminService;

    public AdminController(AdminService adminService) {
        this.adminService = adminService;
    }

    public boolean login(String username, String password) {
        return adminService.login(username, password);
    }

    public List<Product> listProducts() { return adminService.listProducts(); }
    public long addProduct(Product p) { return adminService.addProduct(p); }
    public boolean updateProduct(Product p) { return adminService.updateProduct(p); }
    public boolean deleteProduct(long id) { return adminService.deleteProduct(id); }

    public List<Order> listOrders() { return adminService.listOrders(); }
    public List<OrderItem> listOrderItems(long orderId) { return adminService.listOrderItems(orderId); }
    public boolean updateOrderStatus(long orderId, String status) { return adminService.updateOrderStatus(orderId, status); }
    public boolean deleteOrder(long orderId) { return adminService.deleteOrder(orderId); }
}

