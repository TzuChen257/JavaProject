package controller;


import java.util.List;
import java.util.Map;

import model.Product;
import service.ShopService;



public class ShopController {
    private final ShopService shopService;

    public ShopController(ShopService shopService) {
        this.shopService = shopService;
    }

    public List<Product> loadProductsOnSale() {
        return shopService.listOnSaleProducts();
    }

    public long checkout(String customerName, Map<Long, Integer> cartQtyByProductId) {
        return shopService.checkout(customerName, cartQtyByProductId);
    }
}
