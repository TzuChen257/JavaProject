package dao;


public interface AdminDao {
    boolean verifyLogin(String username, String passwordPlain);
}
