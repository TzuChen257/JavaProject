package dao;

import java.util.List;

import model.Order;
import model.OrderItem;

public interface OrderDao {
    long createOrder(Order order, List<OrderItem> items);

    List<Order> findAll();
    List<OrderItem> findItemsByOrderId(long orderId);

    boolean updateStatus(long orderId, String status);

    boolean deleteOrder(long orderId);
}
