package dao;


import java.util.List;
import java.util.Optional;

import model.Product;



public interface ProductDao {
    List<Product> findAllOnSale();
    List<Product> findAll();
    Optional<Product> findById(long id);
    long insert(Product p);
    boolean update(Product p);
    boolean delete(long id);
}
