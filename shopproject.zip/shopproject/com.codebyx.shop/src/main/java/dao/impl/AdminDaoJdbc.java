package dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import dao.AdminDao;
import util.DbUtil;
import util.HashUtil;

public class AdminDaoJdbc implements AdminDao {

    @Override
    public boolean verifyLogin(String username, String passwordPlain) {
        String sql = "SELECT password_hash FROM admin WHERE username=?";
        try (Connection cn = DbUtil.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return false;
                String stored = rs.getString("password_hash");
                return HashUtil.verify(passwordPlain, stored);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
