package dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import dao.OrderDao;
import model.Order;
import model.OrderItem;
import util.DbUtil;

public class OrderDaoJdbc implements OrderDao {

    @Override
    public long createOrder(Order order, List<OrderItem> items) {
        String insertOrder = "INSERT INTO orders(customer_name,total_amount,status) VALUES(?,?,?)";
        String insertItem  = "INSERT INTO order_item(order_id,product_id,product_name,unit_price,qty,line_amount) VALUES(?,?,?,?,?,?)";
        String deductStock = "UPDATE product SET stock=stock-? WHERE id=? AND stock>=?";

        Connection cn = null;
        try {
            cn = DbUtil.getConnection();
            cn.setAutoCommit(false);

            long orderId;
            try (PreparedStatement ps = cn.prepareStatement(insertOrder, Statement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, order.getCustomerName());
                ps.setBigDecimal(2, order.getTotalAmount());
                ps.setString(3, order.getStatus());
                ps.executeUpdate();

                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (!keys.next()) throw new SQLException("No generated key for order");
                    orderId = keys.getLong(1);
                }
            }

            // 扣庫存（逐筆扣，失敗就 rollback）
            try (PreparedStatement psStock = cn.prepareStatement(deductStock)) {
                for (OrderItem it : items) {
                    psStock.setInt(1, it.getQty());
                    psStock.setLong(2, it.getProductId());
                    psStock.setInt(3, it.getQty());
                    int updated = psStock.executeUpdate();
                    if (updated != 1) throw new SQLException("Stock not enough for productId=" + it.getProductId());
                }
            }

            // 寫明細
            try (PreparedStatement ps = cn.prepareStatement(insertItem)) {
                for (OrderItem it : items) {
                    ps.setLong(1, orderId);
                    ps.setLong(2, it.getProductId());
                    ps.setString(3, it.getProductName());
                    ps.setBigDecimal(4, it.getUnitPrice());
                    ps.setInt(5, it.getQty());
                    ps.setBigDecimal(6, it.getLineAmount());
                    ps.addBatch();
                }
                ps.executeBatch();
            }

            cn.commit();
            return orderId;

        } catch (SQLException e) {
            if (cn != null) {
                try { cn.rollback(); } catch (SQLException ignored) {}
            }
            throw new RuntimeException(e);
        } finally {
            if (cn != null) {
                try { cn.setAutoCommit(true); cn.close(); } catch (SQLException ignored) {}
            }
        }
    }

    @Override
    public List<Order> findAll() {
        String sql = "SELECT id,customer_name,total_amount,status,created_at FROM orders ORDER BY id DESC";
        List<Order> list = new ArrayList<>();
        try (Connection cn = DbUtil.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(mapOrder(rs));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return list;
    }

    @Override
    public List<OrderItem> findItemsByOrderId(long orderId) {
        String sql = "SELECT id,order_id,product_id,product_name,unit_price,qty,line_amount FROM order_item WHERE order_id=? ORDER BY id";
        List<OrderItem> list = new ArrayList<>();
        try (Connection cn = DbUtil.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setLong(1, orderId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapItem(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return list;
    }

    @Override
    public boolean updateStatus(long orderId, String status) {
        String sql = "UPDATE orders SET status=? WHERE id=?";
        try (Connection cn = DbUtil.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setLong(2, orderId);
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public boolean deleteOrder(long orderId) {
        // 先刪明細再刪主檔，避免 FK 問題
        String delItems = "DELETE FROM order_item WHERE order_id=?";
        String delOrder = "DELETE FROM orders WHERE id=?";

        Connection cn = null;
        try {
            cn = DbUtil.getConnection();
            cn.setAutoCommit(false);

            try (PreparedStatement ps = cn.prepareStatement(delItems)) {
                ps.setLong(1, orderId);
                ps.executeUpdate();
            }
            int deleted;
            try (PreparedStatement ps = cn.prepareStatement(delOrder)) {
                ps.setLong(1, orderId);
                deleted = ps.executeUpdate();
            }

            cn.commit();
            return deleted == 1;

        } catch (SQLException e) {
            if (cn != null) {
                try { cn.rollback(); } catch (SQLException ignored) {}
            }
            throw new RuntimeException(e);
        } finally {
            if (cn != null) {
                try { cn.setAutoCommit(true); cn.close(); } catch (SQLException ignored) {}
            }
        }
    }

    private Order mapOrder(ResultSet rs) throws SQLException {
        Order o = new Order();
        o.setId(rs.getLong("id"));
        o.setCustomerName(rs.getString("customer_name"));
        o.setTotalAmount(rs.getBigDecimal("total_amount"));
        o.setStatus(rs.getString("status"));
        Timestamp ts = rs.getTimestamp("created_at");
        o.setCreatedAt(ts != null ? ts.toLocalDateTime() : LocalDateTime.now());
        return o;
    }

    private OrderItem mapItem(ResultSet rs) throws SQLException {
        OrderItem it = new OrderItem();
        it.setId(rs.getLong("id"));
        it.setOrderId(rs.getLong("order_id"));
        it.setProductId(rs.getLong("product_id"));
        it.setProductName(rs.getString("product_name"));
        it.setUnitPrice(rs.getBigDecimal("unit_price"));
        it.setQty(rs.getInt("qty"));
        it.setLineAmount(rs.getBigDecimal("line_amount"));
        return it;
    }
}
