package service;

import java.util.List;

import dao.AdminDao;
import dao.OrderDao;
import dao.ProductDao;
import model.Order;
import model.OrderItem;
import model.Product;

public class AdminService {
    private final AdminDao adminDao;
    private final ProductDao productDao;
    private final OrderDao orderDao;

    public AdminService(AdminDao adminDao, ProductDao productDao, OrderDao orderDao) {
        this.adminDao = adminDao;
        this.productDao = productDao;
        this.orderDao = orderDao;
    }

    public boolean login(String username, String password) {
        if (username == null || username.isBlank()) return false;
        if (password == null) password = "";
        return adminDao.verifyLogin(username, password);
    }

    // Product CRUD
    public List<Product> listProducts() { return productDao.findAll(); }
    public long addProduct(Product p) { return productDao.insert(p); }
    public boolean updateProduct(Product p) { return productDao.update(p); }
    public boolean deleteProduct(long id) { return productDao.delete(id); }

    // Orders
    public List<Order> listOrders() { return orderDao.findAll(); }
    public List<OrderItem> listOrderItems(long orderId) { return orderDao.findItemsByOrderId(orderId); }
    public boolean updateOrderStatus(long orderId, String status) { return orderDao.updateStatus(orderId, status); }
    public boolean deleteOrder(long orderId) { return orderDao.deleteOrder(orderId); }
}
