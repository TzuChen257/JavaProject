package service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import dao.OrderDao;
import dao.ProductDao;
import model.Order;
import model.OrderItem;
import model.Product;

public class ShopService {
    private final ProductDao productDao;
    private final OrderDao orderDao;

    public ShopService(ProductDao productDao, OrderDao orderDao) {
        this.productDao = productDao;
        this.orderDao = orderDao;
    }

    public List<Product> listOnSaleProducts() {
        return productDao.findAllOnSale();
    }

    public long checkout(String customerName, Map<Long, Integer> cartQtyByProductId) {
        if (customerName == null || customerName.isBlank()) {
            throw new IllegalArgumentException("Customer name required.");
        }
        if (cartQtyByProductId == null || cartQtyByProductId.isEmpty()) {
            throw new IllegalArgumentException("Cart is empty.");
        }

        List<OrderItem> items = new ArrayList<>();
        BigDecimal total = BigDecimal.ZERO;

        for (Entry<Long, Integer> entry : cartQtyByProductId.entrySet()) {
            long productId = entry.getKey();
            int qty = entry.getValue();
            if (qty <= 0) continue;

            Product p = productDao.findById(productId)
                    .orElseThrow(() -> new IllegalArgumentException("Product not found: " + productId));

            BigDecimal line = p.getPrice().multiply(BigDecimal.valueOf(qty));

            OrderItem it = new OrderItem();
            it.setProductId(p.getId());
            it.setProductName(p.getName());
            it.setUnitPrice(p.getPrice());
            it.setQty(qty);
            it.setLineAmount(line);

            items.add(it);
            total = total.add(line);
        }

        if (items.isEmpty()) throw new IllegalArgumentException("Cart is empty.");

        Order order = new Order();
        order.setCustomerName(customerName);
        order.setTotalAmount(total);
        order.setStatus("NEW");

        return orderDao.createOrder(order, items);
    }
}

