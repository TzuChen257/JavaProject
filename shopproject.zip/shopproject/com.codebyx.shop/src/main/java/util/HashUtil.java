package util;


import org.mindrot.jbcrypt.BCrypt;

/**
 * 支援兩種模式：
 * 1) {noop}xxx  -> 直接明碼比對（方便你先跑通）
 * 2) BCrypt hash -> 正式用
 */
public class HashUtil {
    public static String bcryptHash(String plain) {
        return BCrypt.hashpw(plain, BCrypt.gensalt(12));
    }

    public static boolean verify(String plain, String stored) {
        if (stored == null) return false;
        if (stored.startsWith("{noop}")) {
            String raw = stored.substring("{noop}".length());
            return raw.equals(plain);
        }
        // 預設當 BCrypt
        return BCrypt.checkpw(plain, stored);
    }
}
