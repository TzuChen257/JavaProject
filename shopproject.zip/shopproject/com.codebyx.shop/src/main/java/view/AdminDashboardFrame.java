package view;


import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JTabbedPane;

import controller.AdminController;



public class AdminDashboardFrame extends JFrame {
    public AdminDashboardFrame(AdminController adminController) {
        setTitle("Admin Dashboard");
        setSize(980, 620);
        setLocationRelativeTo(null);

        setLayout(new BorderLayout());

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("產品管理", new ProductManagePanel(adminController));
        tabs.addTab("訂單管理", new OrderManagePanel(adminController));

        add(tabs, BorderLayout.CENTER);
    }
}
