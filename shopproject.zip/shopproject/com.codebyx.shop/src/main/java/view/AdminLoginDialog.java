package view;



import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.*;

import controller.AdminController;



public class AdminLoginDialog extends JDialog {
    private final AdminController adminController;

    private JTextField txtUser;
    private JPasswordField txtPass;
    private boolean loginSuccess = false;

    public AdminLoginDialog(JFrame owner, AdminController adminController) {
        super(owner, "Admin Login", true);
        this.adminController = adminController;

        setSize(360, 180);
        setLocationRelativeTo(owner);
        initUi();
    }

    private void initUi() {
        JPanel center = new JPanel();
        center.setLayout(new BoxLayout(center, BoxLayout.Y_AXIS));

        JPanel p1 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        p1.add(new JLabel("Username:"));
        txtUser = new JTextField(18);
        p1.add(txtUser);

        JPanel p2 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        p2.add(new JLabel("Password:"));
        txtPass = new JPasswordField(18);
        p2.add(txtPass);

        center.add(p1);
        center.add(p2);

        add(center, BorderLayout.CENTER);

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnLogin = new JButton("Login");
        JButton btnCancel = new JButton("Cancel");
        bottom.add(btnCancel);
        bottom.add(btnLogin);

        btnCancel.addActionListener(e -> dispose());
        btnLogin.addActionListener(e -> doLogin());

        add(bottom, BorderLayout.SOUTH);
    }

    private void doLogin() {
        String u = txtUser.getText();
        String p = new String(txtPass.getPassword());

        boolean ok = adminController.login(u, p);
        if (!ok) {
            JOptionPane.showMessageDialog(this, "登入失敗");
            return;
        }
        loginSuccess = true;
        dispose();
    }

    public boolean isLoginSuccess() {
        return loginSuccess;
    }
}
