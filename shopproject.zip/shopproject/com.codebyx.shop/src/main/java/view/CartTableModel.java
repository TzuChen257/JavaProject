package view;


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.swing.table.AbstractTableModel;

import model.Product;



public class CartTableModel extends AbstractTableModel {
    private final String[] cols = {"ID", "名稱", "單價", "數量", "小計"};
    // 保持加入順序
    private final Map<Long, CartRow> rows = new LinkedHashMap<>();

    public static class CartRow {
        public Product product;
        public int qty;

        public BigDecimal subtotal() {
            return product.getPrice().multiply(BigDecimal.valueOf(qty));
        }
    }

    @Override public int getRowCount() { return rows.size(); }
    @Override public int getColumnCount() { return cols.length; }
    @Override public String getColumnName(int c) { return cols[c]; }

    @Override
    public Class<?> getColumnClass(int c) {
        return Object.class;
    }

    @Override
    public boolean isCellEditable(int r, int c) {
        return c == 3; // qty 可改
    }

    @Override
    public Object getValueAt(int r, int c) {
        CartRow row = getRow(r);
        switch (c) {
            case 0:row.product.getId();
            case 1:row.product.getName();
            case 2:row.product.getPrice();
            case 3:row.product.getStatus();
            case 4:row.subtotal();
            default:;
        };
        return row;
    }

    @Override
    public void setValueAt(Object v, int r, int c) {
        if (c != 3) return;
        CartRow row = getRow(r);
        try {
            int qty = Integer.parseInt(String.valueOf(v));
            if (qty <= 0) qty = 1;
            row.qty = qty;
            fireTableRowsUpdated(r, r);
        } catch (Exception ignored) {}
    }

    private CartRow getRow(int index) {
        List<CartRow> list = new ArrayList<>(rows.values());
        return list.get(index);
    }

    public void addOne(Product p) {
        CartRow row = rows.get(p.getId());
        if (row == null) {
            row = new CartRow();
            row.product = p;
            row.qty = 1;
            rows.put(p.getId(), row);
        } else {
            row.qty += 1;
        }
        fireTableDataChanged();
    }

    public void addMany(List<Product> products) {
        for (Product p : products) addOne(p);
    }

    public void removeRow(int rowIndex) {
        Long key = new ArrayList<>(rows.keySet()).get(rowIndex);
        rows.remove(key);
        fireTableDataChanged();
    }

    public void clear() {
        rows.clear();
        fireTableDataChanged();
    }

    public BigDecimal total() {
        BigDecimal sum = BigDecimal.ZERO;
        for (CartRow r : rows.values()) sum = sum.add(r.subtotal());
        return sum;
    }

    public Map<Long, Integer> toQtyMap() {
        Map<Long, Integer> map = new LinkedHashMap<>();
        for (var e : rows.entrySet()) {
            map.put(e.getKey(), e.getValue().qty);
        }
        return map;
    }

    public boolean isEmpty() {
        return rows.isEmpty();
    }
}
