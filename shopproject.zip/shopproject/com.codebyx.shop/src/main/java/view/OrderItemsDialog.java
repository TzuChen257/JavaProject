package view;



import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.util.List;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import model.OrderItem;



public class OrderItemsDialog extends JDialog {

    public OrderItemsDialog(java.awt.Window owner, long orderId, List<OrderItem> items) {
        super(owner, "Order Items - OrderID=" + orderId, ModalityType.APPLICATION_MODAL);
        setSize(720, 420);
        setLocationRelativeTo(owner);

        DefaultTableModel model = new DefaultTableModel(
                new Object[]{"ItemID","ProductID","Name","UnitPrice","Qty","LineAmount"}, 0) {
            @Override public boolean isCellEditable(int row, int col) { return false; }
        };

        JTable table = new JTable(model);
        table.setRowHeight(24);

        for (OrderItem it : items) {
            model.addRow(new Object[]{
                    it.getId(),
                    it.getProductId(),
                    it.getProductName(),
                    it.getUnitPrice(),
                    it.getQty(),
                    it.getLineAmount()
            });
        }

        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnClose = new JButton("Close");
        btnClose.addActionListener(e -> dispose());
        bottom.add(btnClose);

        add(bottom, BorderLayout.SOUTH);
    }
}
