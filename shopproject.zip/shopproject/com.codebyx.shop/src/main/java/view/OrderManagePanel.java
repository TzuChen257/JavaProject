package view;



import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.util.List;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import controller.AdminController;
import model.Order;
import model.OrderItem;


public class OrderManagePanel extends JPanel {
    private final AdminController adminController;

    private JTable table;
    private DefaultTableModel model;

    private JTextField txtOrderId;
    private JComboBox<String> cbStatus;

    public OrderManagePanel(AdminController adminController) {
        this.adminController = adminController;
        setLayout(new BorderLayout());
        initUi();
        reload();
    }

    private void initUi() {
        model = new DefaultTableModel(new Object[]{"ID","Customer","Total","Status","CreatedAt"}, 0) {
            @Override public boolean isCellEditable(int row, int col) { return false; }
        };
        table = new JTable(model);
        table.setRowHeight(24);
        table.getSelectionModel().addListSelectionListener(e -> fillSelected());

        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.LEFT));
        txtOrderId = new JTextField(8);
        txtOrderId.setEditable(false);
        cbStatus = new JComboBox<>(new String[]{"NEW","PAID","CANCELLED"});

        JButton btnRefresh = new JButton("重新整理");
        JButton btnUpdateStatus = new JButton("更新狀態");
        JButton btnViewItems = new JButton("查看明細");
        JButton btnDelete = new JButton("刪除訂單");

        btnRefresh.addActionListener(e -> reload());
        btnUpdateStatus.addActionListener(e -> updateStatus());
        btnViewItems.addActionListener(e -> viewItems());
        btnDelete.addActionListener(e -> deleteOrder());

        bottom.add(new JLabel("OrderID"));
        bottom.add(txtOrderId);
        bottom.add(new JLabel("Status"));
        bottom.add(cbStatus);

        bottom.add(btnUpdateStatus);
        bottom.add(btnViewItems);
        bottom.add(btnDelete);
        bottom.add(btnRefresh);

        add(bottom, BorderLayout.SOUTH);
    }

    private void reload() {
        try {
            List<Order> list = adminController.listOrders();
            model.setRowCount(0);
            for (Order o : list) {
                model.addRow(new Object[]{
                        o.getId(),
                        o.getCustomerName(),
                        o.getTotalAmount(),
                        o.getStatus(),
                        o.getCreatedAt()
                });
            }
            txtOrderId.setText("");
        } catch (Exception ex) {
            showError(ex);
        }
    }

    private void fillSelected() {
        int row = table.getSelectedRow();
        if (row < 0) return;
        txtOrderId.setText(String.valueOf(model.getValueAt(row, 0)));
        cbStatus.setSelectedItem(String.valueOf(model.getValueAt(row, 3)));
    }

    private void updateStatus() {
        try {
            String sid = txtOrderId.getText();
            if (sid.isBlank()) {
                JOptionPane.showMessageDialog(this, "請先選取一筆訂單");
                return;
            }
            long orderId = Long.parseLong(sid);
            String status = String.valueOf(cbStatus.getSelectedItem());

            boolean ok = adminController.updateOrderStatus(orderId, status);
            JOptionPane.showMessageDialog(this, ok ? "更新成功" : "更新失敗");
            reload();
        } catch (Exception ex) {
            showError(ex);
        }
    }

    private void viewItems() {
        try {
            String sid = txtOrderId.getText();
            if (sid.isBlank()) {
                JOptionPane.showMessageDialog(this, "請先選取一筆訂單");
                return;
            }
            long orderId = Long.parseLong(sid);
            List<OrderItem> items = adminController.listOrderItems(orderId);

            OrderItemsDialog dlg = new OrderItemsDialog(SwingUtilities.getWindowAncestor(this), orderId, items);
            dlg.setVisible(true);

        } catch (Exception ex) {
            showError(ex);
        }
    }

    private void deleteOrder() {
        try {
            String sid = txtOrderId.getText();
            if (sid.isBlank()) {
                JOptionPane.showMessageDialog(this, "請先選取一筆訂單");
                return;
            }
            long orderId = Long.parseLong(sid);

            int confirm = JOptionPane.showConfirmDialog(this, "確定刪除訂單 ID=" + orderId + " ?", "Confirm", JOptionPane.YES_NO_OPTION);
            if (confirm != JOptionPane.YES_OPTION) return;

            boolean ok = adminController.deleteOrder(orderId);
            JOptionPane.showMessageDialog(this, ok ? "刪除成功" : "刪除失敗");
            reload();

        } catch (Exception ex) {
            showError(ex);
        }
    }

    private void showError(Exception ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}

