package view;



import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.math.BigDecimal;
import java.util.List;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import controller.AdminController;
import model.Product;



public class ProductManagePanel extends JPanel {
    private final AdminController adminController;

    private JTable table;
    private DefaultTableModel model;

    private JTextField txtId, txtName, txtPrice, txtStock, txtStatus;

    public ProductManagePanel(AdminController adminController) {
        this.adminController = adminController;
        setLayout(new BorderLayout());
        initUi();
        reload();
    }

    private void initUi() {
        model = new DefaultTableModel(new Object[]{"ID","Name","Price","Stock","Status"}, 0) {
            @Override public boolean isCellEditable(int row, int col) { return false; }
        };
        table = new JTable(model);
        table.setRowHeight(24);
        table.getSelectionModel().addListSelectionListener(e -> fillFormFromSelected());

        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel form = new JPanel(new FlowLayout(FlowLayout.LEFT));
        txtId = new JTextField(6); txtId.setEditable(false);
        txtName = new JTextField(12);
        txtPrice = new JTextField(8);
        txtStock = new JTextField(6);
        txtStatus = new JTextField(4);

        form.add(new JLabel("ID")); form.add(txtId);
        form.add(new JLabel("Name")); form.add(txtName);
        form.add(new JLabel("Price")); form.add(txtPrice);
        form.add(new JLabel("Stock")); form.add(txtStock);
        form.add(new JLabel("Status(1/0)")); form.add(txtStatus);

        JButton btnAdd = new JButton("新增");
        JButton btnUpdate = new JButton("更新");
        JButton btnDelete = new JButton("刪除");
        JButton btnReload = new JButton("重新整理");

        btnAdd.addActionListener(e -> addProduct());
        btnUpdate.addActionListener(e -> updateProduct());
        btnDelete.addActionListener(e -> deleteProduct());
        btnReload.addActionListener(e -> reload());

        form.add(btnAdd);
        form.add(btnUpdate);
        form.add(btnDelete);
        form.add(btnReload);

        add(form, BorderLayout.SOUTH);
    }

    private void reload() {
        try {
            List<Product> list = adminController.listProducts();
            model.setRowCount(0);
            for (Product p : list) {
                model.addRow(new Object[]{p.getId(), p.getName(), p.getPrice(), p.getStock(), p.getStatus()});
            }
            clearForm();
        } catch (Exception ex) {
            showError(ex);
        }
    }

    private void fillFormFromSelected() {
        int row = table.getSelectedRow();
        if (row < 0) return;
        txtId.setText(String.valueOf(model.getValueAt(row, 0)));
        txtName.setText(String.valueOf(model.getValueAt(row, 1)));
        txtPrice.setText(String.valueOf(model.getValueAt(row, 2)));
        txtStock.setText(String.valueOf(model.getValueAt(row, 3)));
        txtStatus.setText(String.valueOf(model.getValueAt(row, 4)));
    }

    private void addProduct() {
        try {
            Product p = readForm(false);
            long id = adminController.addProduct(p);
            JOptionPane.showMessageDialog(this, "新增成功 ID=" + id);
            reload();
        } catch (Exception ex) {
            showError(ex);
        }
    }

    private void updateProduct() {
        try {
            Product p = readForm(true);
            boolean ok = adminController.updateProduct(p);
            JOptionPane.showMessageDialog(this, ok ? "更新成功" : "更新失敗");
            reload();
        } catch (Exception ex) {
            showError(ex);
        }
    }

    private void deleteProduct() {
        try {
            String sid = txtId.getText();
            if (sid.isBlank()) {
                JOptionPane.showMessageDialog(this, "請先選取一筆產品");
                return;
            }
            long id = Long.parseLong(sid);
            int confirm = JOptionPane.showConfirmDialog(this, "確定刪除產品 ID=" + id + " ?", "Confirm", JOptionPane.YES_NO_OPTION);
            if (confirm != JOptionPane.YES_OPTION) return;

            boolean ok = adminController.deleteProduct(id);
            JOptionPane.showMessageDialog(this, ok ? "刪除成功" : "刪除失敗");
            reload();
        } catch (Exception ex) {
            showError(ex);
        }
    }

    private Product readForm(boolean needId) {
        String sid = txtId.getText().trim();
        String name = txtName.getText().trim();
        String sprice = txtPrice.getText().trim();
        String sstock = txtStock.getText().trim();
        String sstatus = txtStatus.getText().trim();

        if (name.isBlank()) throw new IllegalArgumentException("Name required");
        BigDecimal price = new BigDecimal(sprice);
        int stock = Integer.parseInt(sstock);
        int status = Integer.parseInt(sstatus);

        Product p = new Product();
        if (needId) {
            if (sid.isBlank()) throw new IllegalArgumentException("Select a product first");
            p.setId(Long.parseLong(sid));
        }
        p.setName(name);
        p.setPrice(price);
        p.setStock(stock);
        p.setStatus(status);
        return p;
    }

    private void clearForm() {
        txtId.setText("");
        txtName.setText("");
        txtPrice.setText("");
        txtStock.setText("");
        txtStatus.setText("1");
    }

    private void showError(Exception ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}
