package view;


import javax.swing.table.AbstractTableModel;

import model.Product;

import java.util.*;

public class ProductTableModel extends AbstractTableModel {
    private final String[] cols = {"選取", "ID", "名稱", "價格", "庫存"};
    private final List<Product> data;
    private final List<Boolean> selected;

    public ProductTableModel(List<Product> data) {
        this.data = data != null ? data : new ArrayList<>();
        this.selected = new ArrayList<>(Collections.nCopies(this.data.size(), Boolean.FALSE));
    }

    @Override public int getRowCount() { return data.size(); }
    @Override public int getColumnCount() { return cols.length; }
    @Override public String getColumnName(int column) { return cols[column]; }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        if (columnIndex == 0) return Boolean.class;
        if (columnIndex == 1) return Long.class;
        return Object.class;
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return columnIndex == 0; // 只有 checkbox 可編輯
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Product p = data.get(rowIndex);

        switch (columnIndex) {
            case 0:
                return selected.get(rowIndex);   // Boolean（checkbox）
            case 1:
                return p.getId();
            case 2:
                return p.getName();
            case 3:
                return p.getPrice();
            case 4:
                return p.getStock();
            default:
                return null;
        }
    }


    @Override
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        if (columnIndex == 0) {
            selected.set(rowIndex, Boolean.TRUE.equals(aValue));
            fireTableCellUpdated(rowIndex, columnIndex);
        }
    }

    public Product getProductAt(int row) {
        return data.get(row);
    }

    public List<Product> getSelectedProducts() {
        List<Product> list = new ArrayList<>();
        for (int i = 0; i < data.size(); i++) {
            if (Boolean.TRUE.equals(selected.get(i))) list.add(data.get(i));
        }
        return list;
    }
}
