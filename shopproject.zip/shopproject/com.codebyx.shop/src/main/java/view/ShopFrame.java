package view;


import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.math.BigDecimal;
import java.util.List;

import javax.swing.*;

import controller.AdminController;
import controller.ShopController;
import model.Product;


public class ShopFrame extends JFrame {
    private final ShopController shopController;
    private final AdminController adminController;

    private JTable tblProducts;
    private JTable tblCart;
    private JLabel lblTotal;
    private JTextField txtCustomer;

    private ProductTableModel productModel;
    private CartTableModel cartModel = new CartTableModel();

    public ShopFrame(ShopController shopController, AdminController adminController) {
        this.shopController = shopController;
        this.adminController = adminController;

        setTitle("Desktop Shop (Swing + MVC + DAO)");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(980, 600);
        setLocationRelativeTo(null);

        initUi();
        reloadProducts();
    }

    private void initUi() {
        setLayout(new BorderLayout());

        // Top: toolbar
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnReload = new JButton("重新載入商品");
        JButton btnAdmin = new JButton("後台管理");

        top.add(btnReload);
        top.add(btnAdmin);

        add(top, BorderLayout.NORTH);

        btnReload.addActionListener(e -> reloadProducts());
        btnAdmin.addActionListener(e -> openAdmin());

        // Center split: products + cart
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        split.setResizeWeight(0.55);

        // Left: products
        JPanel left = new JPanel(new BorderLayout());
        left.setBorder(BorderFactory.createTitledBorder("商品列表（可複選）"));

        tblProducts = new JTable();
        tblProducts.setRowHeight(24);
        JScrollPane sp1 = new JScrollPane(tblProducts);
        left.add(sp1, BorderLayout.CENTER);

        JPanel leftBtns = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnAddSingle = new JButton("單選加入( +1 )");
        JButton btnAddMulti = new JButton("複選加入( +1 )");
        leftBtns.add(btnAddSingle);
        leftBtns.add(btnAddMulti);
        left.add(leftBtns, BorderLayout.SOUTH);

        btnAddSingle.addActionListener(e -> addSingle());
        btnAddMulti.addActionListener(e -> addMulti());

        // Right: cart
        JPanel right = new JPanel(new BorderLayout());
        right.setBorder(BorderFactory.createTitledBorder("購物車（可改數量）"));

        tblCart = new JTable(cartModel);
        tblCart.setRowHeight(24);
        JScrollPane sp2 = new JScrollPane(tblCart);
        sp2.setPreferredSize(new Dimension(420, 300));
        right.add(sp2, BorderLayout.CENTER);

        JPanel cartBottom = new JPanel(new BorderLayout());

        JPanel info = new JPanel(new FlowLayout(FlowLayout.LEFT));
        info.add(new JLabel("顧客姓名："));
        txtCustomer = new JTextField(14);
        info.add(txtCustomer);

        lblTotal = new JLabel("總計：0");
        info.add(lblTotal);

        cartBottom.add(info, BorderLayout.NORTH);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnRemove = new JButton("移除選取項目");
        JButton btnClear = new JButton("清空購物車");
        JButton btnCheckout = new JButton("結帳");

        actions.add(btnRemove);
        actions.add(btnClear);
        actions.add(btnCheckout);

        cartBottom.add(actions, BorderLayout.SOUTH);

        btnRemove.addActionListener(e -> removeCartRow());
        btnClear.addActionListener(e -> {
            cartModel.clear();
            refreshTotal();
        });
        btnCheckout.addActionListener(e -> checkout());

        right.add(cartBottom, BorderLayout.SOUTH);

        split.setLeftComponent(left);
        split.setRightComponent(right);

        add(split, BorderLayout.CENTER);
    }

    private void reloadProducts() {
        try {
            List<Product> products = shopController.loadProductsOnSale();
            productModel = new ProductTableModel(products);
            tblProducts.setModel(productModel);

            // 單選模式（配合你的「單選加入」）
            tblProducts.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        } catch (Exception ex) {
            showError(ex);
        }
    }

    private void addSingle() {
        if (productModel == null) return;
        int row = tblProducts.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "請先單選一個商品列");
            return;
        }
        Product p = productModel.getProductAt(row);
        cartModel.addOne(p);
        refreshTotal();
    }

    private void addMulti() {
        if (productModel == null) return;
        List<Product> selected = productModel.getSelectedProducts();
        if (selected.isEmpty()) {
            JOptionPane.showMessageDialog(this, "請勾選至少一個商品（左邊第一欄選取）");
            return;
        }
        cartModel.addMany(selected);
        refreshTotal();
    }

    private void removeCartRow() {
        int row = tblCart.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "請先選取購物車的一列");
            return;
        }
        cartModel.removeRow(row);
        refreshTotal();
    }

    private void refreshTotal() {
        BigDecimal total = cartModel.total();
        lblTotal.setText("總計：" + total);
    }

    private void checkout() {
        try {
            if (cartModel.isEmpty()) {
                JOptionPane.showMessageDialog(this, "購物車是空的");
                return;
            }
            String customer = txtCustomer.getText();
            long orderId = shopController.checkout(customer, cartModel.toQtyMap());

            JOptionPane.showMessageDialog(this, "結帳成功！訂單編號：" + orderId);

            cartModel.clear();
            refreshTotal();
            reloadProducts(); // 庫存變動後刷新
        } catch (Exception ex) {
            showError(ex);
        }
    }

    private void openAdmin() {
        AdminLoginDialog dlg = new AdminLoginDialog(this, adminController);
        dlg.setVisible(true);
        if (dlg.isLoginSuccess()) {
            AdminDashboardFrame dash = new AdminDashboardFrame(adminController);
            dash.setVisible(true);
        }
    }

    private void showError(Exception ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}

